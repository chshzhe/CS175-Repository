package com.example.finalproject;

public class Constants {
    public static final String BASE_URL = "https://api-sjtu-camp-2021.bytedance.com/homework/invoke/";
    public static final String STUDENT_ID = "xxxx";
    public static final String USER_NAME = "ZhangSan";
}
