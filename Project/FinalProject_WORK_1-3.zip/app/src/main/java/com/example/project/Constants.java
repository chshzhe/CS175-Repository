package com.example.project;

public class Constants {
    public static final String BASE_URL = "https://api-sjtu-camp-2021.bytedance.com/homework/invoke/";
    public static final String token = "U0pUVS1ieXRlZGFuY2UtYW5kcm9pZA==";
    public static final String STUDENT_ID = "519070910059";
    public static final String USER_NAME = "陈爽哲";
}
