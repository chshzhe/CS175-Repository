package com.wildeyess.player.utils.autolinktextview;

public interface AutoLinkOnClickListener {

    void onAutoLinkTextClick(AutoLinkMode autoLinkMode, String matchedText);
}
