package com.wildeyess.player.model.bean;

import com.wildeyess.player.R;
import java.util.ArrayList;

/**
 * create by wildeyess
 * create on 2020-06-03
 * description 本地数据创建，代替接口获取数据
 */
public class DataCreate {
    public static ArrayList<VideoBean> datas = new ArrayList<>();
    public static ArrayList<VideoBean.UserBean> userList = new ArrayList<>();

    public void initData() {

        VideoBean videoBeanOne = new VideoBean();
        videoBeanOne.setCoverRes(R.mipmap.cover1);
        videoBeanOne.setContent("#宠物 论气质这块，输过谁");
        videoBeanOne.setVideoRes(R.raw.video1);
        videoBeanOne.setDistance(7.9f);
        videoBeanOne.setFocused(false);
        videoBeanOne.setLiked(true);
        videoBeanOne.setLikeCount(123823);
        videoBeanOne.setCommentCount(3480);
        videoBeanOne.setShareCount(4252);

        VideoBean.UserBean userBeanOne = new VideoBean.UserBean();
        userBeanOne.setUid(1);
        userBeanOne.setHead(R.mipmap.head1);
        userBeanOne.setNickName("EA7-花臂King");
        userBeanOne.setSign("放荡不羁爱自由");
        userBeanOne.setSubCount(119323);
        userBeanOne.setFocusCount(482);
        userBeanOne.setFansCount(32823);
        userBeanOne.setWorkCount(42);
        userBeanOne.setDynamicCount(42);
        userBeanOne.setLikeCount(821);

        userList.add(userBeanOne);
        videoBeanOne.setUserBean(userBeanOne);

        VideoBean videoBeanTwo = new VideoBean();
        videoBeanTwo.setCoverRes(R.mipmap.cover2);
        videoBeanTwo.setContent("一听就是刚换的引擎...");
        videoBeanTwo.setVideoRes(R.raw.video2);
        videoBeanTwo.setDistance(19.7f);
        videoBeanTwo.setFocused(true);
        videoBeanTwo.setLiked(false);
        videoBeanTwo.setLikeCount(55001);
        videoBeanTwo.setCommentCount(8923);
        videoBeanTwo.setShareCount(5892);

        VideoBean.UserBean userBeanTwo = new VideoBean.UserBean();
        userBeanTwo.setUid(2);
        userBeanTwo.setHead( R.mipmap.head2);
        userBeanTwo.setNickName("行走的果皮箱");
        userBeanTwo.setSign("你正常吗？我不正常HHH");
        userBeanTwo.setSubCount(20323234);
        userBeanTwo.setFocusCount(244);
        userBeanTwo.setFansCount(1938232);
        userBeanTwo.setWorkCount(123);
        userBeanTwo.setDynamicCount(123);
        userBeanTwo.setLikeCount(344);

        userList.add(userBeanTwo);
        videoBeanTwo.setUserBean(userBeanTwo);

        VideoBean videoBeanThree = new VideoBean();
        videoBeanThree.setCoverRes(R.mipmap.cover3);
        videoBeanThree.setContent("这是我住过一年的地方，有雪山，有星空，早上刷着牙看着日照金山，下雪了可以跟朋友打雪仗，冷了就烤火。 #带你看雪");
        videoBeanThree.setVideoRes(R.raw.video3);
        videoBeanThree.setDistance(15.9f);
        videoBeanThree.setFocused(false);
        videoBeanThree.setLiked(false);
        videoBeanThree.setLikeCount(2288);
        videoBeanThree.setCommentCount(141);
        videoBeanThree.setShareCount(22);

        VideoBean.UserBean userBeanThree = new VideoBean.UserBean();
        userBeanThree.setUid(3);
        userBeanThree.setHead(R.mipmap.head3);
        userBeanThree.setNickName("尼尔森");
        userBeanThree.setSign("15年开始独自旅行，后来干脆把兴趣当做职业");
        userBeanThree.setSubCount(1039232);
        userBeanThree.setFocusCount(159);
        userBeanThree.setFansCount(29232323);
        userBeanThree.setWorkCount(171);
        userBeanThree.setDynamicCount(173);
        userBeanThree.setLikeCount(1724);

        userList.add(userBeanThree);
        videoBeanThree.setUserBean(userBeanThree);

        VideoBean videoBeanFour = new VideoBean();
        videoBeanFour.setCoverRes(R.mipmap.cover4);
        videoBeanFour.setContent("美好的一天，从发现美开始 #莉莉柯林斯 ");
        videoBeanFour.setVideoRes(R.raw.video4);
        videoBeanFour.setDistance(25.2f);
        videoBeanFour.setFocused(false);
        videoBeanFour.setLiked(false);
        videoBeanFour.setLikeCount(887232);
        videoBeanFour.setCommentCount(2731);
        videoBeanFour.setShareCount(8924);

        VideoBean.UserBean userBeanFour = new VideoBean.UserBean();
        userBeanFour.setUid(4);
        userBeanFour.setHead(R.mipmap.head4);
        userBeanFour.setNickName("一只爱修图的剪辑师");
        userBeanFour.setSign("接剪辑，活动拍摄，修图单\n 合作私信");
        userBeanFour.setSubCount(2689424);
        userBeanFour.setFocusCount(399);
        userBeanFour.setFansCount(360829);
        userBeanFour.setWorkCount(562);
        userBeanFour.setDynamicCount(570);
        userBeanFour.setLikeCount(4310);

        userList.add(userBeanFour);
        videoBeanFour.setUserBean(userBeanFour);

        VideoBean videoBeanFive = new VideoBean();
        videoBeanFive.setCoverRes(R.mipmap.cover5);
        videoBeanFive.setContent("有梦就去追吧，我说到做到。 #网球  #网球小威 ");
        videoBeanFive.setVideoRes(R.raw.video5);
        videoBeanFive.setDistance(9.2f);
        videoBeanFive.setFocused(false);
        videoBeanFive.setLiked(false);
        videoBeanFive.setLikeCount(8293241);
        videoBeanFive.setCommentCount(982);
        videoBeanFive.setShareCount(8923);

        VideoBean.UserBean userBeanFive = new VideoBean.UserBean();
        userBeanFive.setUid(5);
        userBeanFive.setHead(R.mipmap.head5);
        userBeanFive.setNickName("国际网球联合会");
        userBeanFive.setSign("ITF国际网球联合会负责制定统一的网球规则，在世界范围内普及网球运动");
        userBeanFive.setSubCount(1002342);
        userBeanFive.setFocusCount(87);
        userBeanFive.setFansCount(520232);
        userBeanFive.setWorkCount(89);
        userBeanFive.setDynamicCount(122);
        userBeanFive.setLikeCount(9);

        userList.add(userBeanFive);
        videoBeanFive.setUserBean(userBeanFive);

        VideoBean videoBeanSix = new VideoBean();
        videoBeanSix.setCoverRes(R.mipmap.cover6);
        videoBeanSix.setContent("能力越大，责任越大，英雄可能会迟到，但永远不会缺席  #蜘蛛侠 ");
        videoBeanSix.setVideoRes(R.raw.video6);
        videoBeanSix.setDistance(16.4f);
        videoBeanSix.setFocused(true);
        videoBeanSix.setLiked(true);
        videoBeanSix.setLikeCount(2109823);
        videoBeanSix.setCommentCount(9723);
        videoBeanFive.setShareCount(424);

        VideoBean.UserBean userBeanSix = new VideoBean.UserBean();
        userBeanSix.setUid(6);
        userBeanSix.setHead(R.mipmap.head6);
        userBeanSix.setNickName("罗鑫颖");
        userBeanSix.setSign("一个行走在Tr与剪辑之间的人\n 有什么不懂的可以来直播间问我");
        userBeanSix.setSubCount(29342320);
        userBeanSix.setFocusCount(67);
        userBeanSix.setFansCount(7028323);
        userBeanSix.setWorkCount(5133);
        userBeanSix.setDynamicCount(5159);
        userBeanSix.setLikeCount(0);

        userList.add(userBeanSix);
        videoBeanSix.setUserBean(userBeanSix);

        VideoBean videoBeanSeven = new VideoBean();
        videoBeanSeven.setCoverRes(R.mipmap.cover7);
        videoBeanSeven.setContent("真的拍不出来你的神颜！现场看大屏帅疯！#陈情令南京演唱会 #王一博 😭");
        videoBeanSeven.setVideoRes(R.raw.video7);
        videoBeanSeven.setDistance(16.4f);
        videoBeanSeven.setFocused(false);
        videoBeanSeven.setLiked(false);
        videoBeanSeven.setLikeCount(185782);
        videoBeanSeven.setCommentCount(2452);
        videoBeanSeven.setShareCount(3812);

        VideoBean.UserBean userBeanSeven = new VideoBean.UserBean();
        userBeanSeven.setUid(7);
        userBeanSeven.setHead(R.mipmap.head7);
        userBeanSeven.setNickName("Sean");
        userBeanSeven.setSign("云深不知处");
        userBeanSeven.setSubCount(471932);
        userBeanSeven.setFocusCount(482);
        userBeanSeven.setFansCount(371423);
        userBeanSeven.setWorkCount(242);
        userBeanSeven.setDynamicCount(245);
        userBeanSeven.setLikeCount(839);

        userList.add(userBeanSeven);
        videoBeanSeven.setUserBean(userBeanSeven);

        VideoBean videoBeanEight = new VideoBean();
        videoBeanEight.setCoverRes(R.mipmap.cover8);
        videoBeanEight.setContent("逆序只是想告诉大家，学了舞蹈的她气质开了挂！");
        videoBeanEight.setVideoRes(R.raw.video8);
        videoBeanEight.setDistance(8.4f);
        videoBeanEight.setFocused(false);
        videoBeanEight.setLiked(false);
        videoBeanEight.setLikeCount(1708324);
        videoBeanEight.setCommentCount(8372);
        videoBeanEight.setShareCount(982);

        VideoBean.UserBean userBeanEight = new VideoBean.UserBean();
        userBeanEight.setUid(8);
        userBeanEight.setHead(R.mipmap.head8);
        userBeanEight.setNickName("曹小宝");
        userBeanEight.setSign("一个晒娃狂魔麻麻，平日里没啥爱好！喜欢拿着手机记录孩子成长片段，风格不喜勿喷！");
        userBeanEight.setSubCount(1832342);
        userBeanEight.setFocusCount(397);
        userBeanEight.setFansCount(1394232);
        userBeanEight.setWorkCount(164);
        userBeanEight.setDynamicCount(167);
        userBeanEight.setLikeCount(0);

        userList.add(userBeanEight);
        videoBeanEight.setUserBean(userBeanEight);

        datas.add(videoBeanOne);
        datas.add(videoBeanTwo);
        datas.add(videoBeanThree);
        datas.add(videoBeanFour);
        datas.add(videoBeanFive);
        datas.add(videoBeanSix);
        datas.add(videoBeanSeven);
        datas.add(videoBeanEight);


        datas.add(videoBeanOne);
        datas.add(videoBeanTwo);
        datas.add(videoBeanThree);
        datas.add(videoBeanFour);
        datas.add(videoBeanFive);
        datas.add(videoBeanSix);
        datas.add(videoBeanSeven);
        datas.add(videoBeanEight);

    }
}
