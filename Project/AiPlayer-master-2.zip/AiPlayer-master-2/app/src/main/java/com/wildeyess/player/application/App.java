package com.wildeyess.player.application;

import android.app.Application;

/**
 * create by wildeyess
 * create on 2020-10-19
 * description 全局Application
 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }

}
