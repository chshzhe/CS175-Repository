package com.wildeyess.player.utils;

/**
 * create by apple
 * create on 2020-10-20
 * description
 */
public class ViewPagerPlayManager {
}
