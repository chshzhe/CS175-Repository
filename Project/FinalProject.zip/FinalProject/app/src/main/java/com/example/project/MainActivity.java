package com.example.project;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView home,friends,messages,me,currentView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        home=findViewById(R.id.home);
        clicked(home);
        friends=findViewById(R.id.friends);
        released(friends);
        messages=findViewById(R.id.messages);
        released(messages);
        me=findViewById(R.id.me);
        released(me);
        home.setOnClickListener(this);
        friends.setOnClickListener(this);
        messages.setOnClickListener(this);
        me.setOnClickListener(this);
        currentView=home;


    }
    @Override
    public void onClick(View v) {
        released(currentView);
        switch (v.getId()){
            case R.id.home:
                currentView=home;
                clicked(currentView);
                break;
            case R.id.friends:
                currentView=friends;
                clicked(currentView);
                break;
            case R.id.messages:
                currentView=messages;
                clicked(currentView);

                Intent intent = new Intent(this, MessageActivity.class);
                startActivity(intent);
                break;
            case R.id.me:
                currentView=me;
                clicked(currentView);
                break;
        }
    }

    public void clicked(TextView textView){

        textView.setTextColor(Color.WHITE);
        textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
    }
    public void released(TextView textView){

        textView.setTextColor(Color.GRAY);
        textView.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
    }

}